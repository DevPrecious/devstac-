from django.db import models
from django.contrib.auth.models import User
from PIL import Image
from django.urls import reverse
from datetime import datetime, date
from ckeditor.fields import RichTextField

# Create your models here.

class Profile(models.Model):
	user = models.OneToOneField(User, on_delete=models.CASCADE)
	about_me = models.TextField(max_length=200, default="I am ........")
	skills = models.TextField(max_length=200, default="Am good at...")
	github = models.URLField(max_length=200, default="Github link")
	twitter = models.URLField(max_length=200, default="Twitter link")
	link = models.URLField(max_length=200, default="Linkedin link")
	stack = models.URLField(max_length=200, default="Stackoverflow link")
	image = models.ImageField(default='default.png', upload_to='profile_pics')

	def __str__(self):
		return f'{self.user.username} Profile'

	def save(self, *args, **kwargs):
		super(Profile, self).save(*args, **kwargs)

		img = Image.open(self.image.path)

		if img.height > 300 or img.width > 300:
			output_size = (300, 300)
			img.thumbnail(output_size)
			img.save(self.image.path)

class Category(models.Model):
	name = models.CharField(max_length=225)
	
	def __str__(self):
		return self.name

	def get_absolute_url(self):
		return reverse('home')

class Post(models.Model):
	title = models.CharField(max_length=225)
	title_tag = models.CharField(max_length=225, default="Stacked post")
	author = models.ForeignKey(User, on_delete=models.CASCADE)
	body = RichTextField(blank=True, null=True)
	post_date = models.DateField(auto_now_add=True)
	category = models.CharField(max_length=225, default="web development")
	likes = models.ManyToManyField(User, related_name='blog_posts')
	image = models.ImageField(default='tech1.jpg', upload_to='profile_pics')

	def total_likes(self):
		return self.likes.count()



	def __str__(self):
		return self.title + '|' + str(self.author.username)

	def get_absolute_url(self):
		return reverse('home')

