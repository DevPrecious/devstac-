from django.urls import path
from . import views
from .views import HomeView, ArticleView, AddPostView, UserAbout



urlpatterns = [
	#path('', views.index, name="home"),
	path('', HomeView.as_view(), name="home"),
	path('register/', views.registerPage, name="register"),
	path('login/', views.loginPage, name="login"),
	path('profile/', views.aboutPage, name="profile"),
	path('add_post/', AddPostView.as_view(), name="add_post"),
	path('detail/<int:pk>/', ArticleView.as_view(), name="details"),
	path('user/<int:pk>/', UserAbout.as_view(), name="user_about"),
	path('like/<int:pk>/', views.LikeView, name="like_post"),
	path('logout/', views.logoutUser, name="logout"),
]