from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponseRedirect
from .models import *
from .forms import *
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.views.generic import ListView, DetailView, CreateView
from django.urls import reverse_lazy, reverse

# Create your views here.

#def index(request):
	#return render(request, 'student/index.html')
def LikeView(request, pk):
	post = get_object_or_404(Post, id=request.POST.get('post_id'))
	post.likes.add(request.user)
	return HttpResponseRedirect(reverse('details', args=[str(pk)]))



class HomeView(ListView):
	model = Post
	template_name = 'student/index.html'
	ordering = ['-id']

class ArticleView(DetailView):
	model = Post
	template_name = 'student/detail.html'

	def get_context_data(self, *args, **kwargs):
		context = super(ArticleView, self).get_context_data(*args, **kwargs)
		stuff = get_object_or_404(Post, id=self.kwargs['pk'])
		total_likes = stuff.total_likes()
		context["total_likes"] = total_likes
		return context

class UserAbout(DetailView):
	model = Post
	template_name = 'student/about_user.html'



def registerPage(request):
	form = CreateUserForm()
	if request.method == 'POST':
		form = CreateUserForm(request.POST)
		if form.is_valid():
			form.save()
			user = form.cleaned_data.get('username')
			messages.success(request, 'Account created for ' + user)
			return redirect('login')
	context = {'form': form}
	return render(request, 'student/register.html', context)

def loginPage(request):
	if request.method == 'POST':
		username = request.POST.get('username')
		password = request.POST.get('password')
		user = authenticate(request, username=username, password=password)
		if user is not None:
			login(request, user)
			return redirect('home')
		else:
			messages.info(request, 'Wrong username or password')
	context = {}
	return render(request, 'student/login.html', context)

@login_required(login_url='login')
def aboutPage(request):
	if request.method == 'POST':
		u_form = UserUpdateForm(request.POST, instance=request.user)
		p_form = ProfileUpdateForm(request.POST, 
									request.FILES, 
									instance=request.user.profile)
		if u_form.is_valid() and p_form.is_valid():
			u_form.save()
			p_form.save()
			messages.success(request, 'Account updated')
			return redirect('profile')

	else:
		u_form = UserUpdateForm(instance=request.user)
		p_form = ProfileUpdateForm(instance=request.user.profile)

	context = {
	'u_form':u_form,
	'p_form':p_form
	}

	return render(request, 'student/about.html', context)

class AddPostView(CreateView):
	model = Post
	form_class = PostForm
	template_name = 'add_post.html'
	#fields = '__all__'
	#fields = ('title', 'body')


def logoutUser(request):
	logout(request)
	return redirect('login')